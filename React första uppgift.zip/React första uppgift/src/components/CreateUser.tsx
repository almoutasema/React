import React, { useState } from "react";
import TextInput from "./TextInput";
import { useCreateUserMutation } from "./path/to/usersApi";

interface CreateUserProps {
  firstName: string;
  lastName: string;
}

const CreateUser: React.FC<CreateUserProps> = ({ firstName, lastName }) => {
  const [createUserMutation] = useCreateUserMutation();
  const [feedback, setFeedback] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const submitHandler = () => {
    if (firstName !== '' && lastName !== '') {
      setFeedback(`Hej ${firstName} ${lastName}, välkommen!`);
      setSubmitted(true);

      setTimeout(() => {
        setFeedback('');
      }, 5000);

      createUserMutation({
        user: {
          firstName: firstName,
          lastName: lastName
        }
      });
    } else {
      setSubmitted(false);
      setFeedback('Du måste fylla i alla fält!');
    }
  };

  return (
    <div
      style={{
        backgroundColor: 'white',
        padding: '1.6rem',
        borderRadius: '0.2rem',
        display: 'flex',
        flexDirection: 'column'
      }}
    >
      <TextInput
        value={firstName}
        placeholder="Firstname"
        onInput={(event) => {
        }}
      />
      <TextInput
        value={lastName}
        placeholder="Lastname"
        onInput={(event) => {
        }}
      />
      <button onClick={submitHandler}>Tjoho!!</button>
      <p style={{ color: submitted ? 'green' : 'red' }}>{feedback}</p>
    </div>
  );
};

export default CreateUser;

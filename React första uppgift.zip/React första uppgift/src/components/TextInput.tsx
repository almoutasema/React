const TextInput = (props) => {
	const { placeholder, value, onInput }	= props

	return (
		<input
			style={{ marginBottom: '1rem' }}
			type="text"
			value={value}
			placeholder={placeholder}
			// onInput={(event) => {console.log(event)}}
			onInput={onInput}
		/>
	)
}

export default TextInput;

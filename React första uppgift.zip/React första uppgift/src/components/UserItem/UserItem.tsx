import React from 'react';

interface UserItemProps {
  user: any; 
}

const UserItem: React.FC<UserItemProps> = ({ user }) => {
  return <li>{user.name}</li>; 
};

export default UserItem;

import React from 'react';
import UserItem from '../UserItem/UserItem';

interface UserListProps {
  users: any[]; 
}

const UserList: React.FC<UserListProps> = ({ users }) => {
  return (
    <ul>
      {users.map((user) => (
        <UserItem key={user.id} user={user} />
      ))}
    </ul>
  );
};

export default UserList;

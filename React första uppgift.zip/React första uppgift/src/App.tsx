import React from "react";
import "./App.css";

import CreateUser from "./components/CreateUser";

function App() {
  // Define sample user data
  const userData = {
    firstName: "Adam",
    lastName: "Asad"
  };

  return (
    <div className="App">
      <header className="App-header">
        <CreateUser {...userData} />
      </header>
    </div>
  );
}

export default App;

// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

import { getFirestore } from 'firebase/firestore';

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCCfodC8O6OFWfo66RqBW7Yj0Hn11db-Es",
  authDomain: "first11-4436e.firebaseapp.com",
  projectId: "first11-4436e",
  storageBucket: "first11-4436e.appspot.com",
  messagingSenderId: "660501058127",
  appId: "1:660501058127:web:0d2caee63bf1151a5b903a"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export const db = getFirestore()